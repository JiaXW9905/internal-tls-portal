#!/usr/bin/env bash
set -euo pipefail

APP_NAME="internal-tls-portal"
APP_DIR="/opt/${APP_NAME}"
ENV_FILE="/etc/${APP_NAME}.env"
TARBALL="${1:-}"

if [[ -z "${TARBALL}" ]]; then
  echo "Usage: ./deploy/install.sh /path/to/internal-tls-portal.tar.gz"
  exit 1
fi

if [[ ! -f "${TARBALL}" ]]; then
  echo "Tarball not found: ${TARBALL}"
  exit 1
fi

if ! command -v sudo >/dev/null 2>&1; then
  echo "sudo is required."
  exit 1
fi

install_node() {
  if command -v node >/dev/null 2>&1; then
    return
  fi
  curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
  sudo apt-get install -y nodejs
}

install_nginx() {
  if command -v nginx >/dev/null 2>&1; then
    return
  fi
  sudo apt-get update -y
  sudo apt-get install -y nginx
}

echo "Installing Node.js if missing..."
install_node

echo "Installing Nginx if missing..."
install_nginx

echo "Extracting package..."
sudo mkdir -p "${APP_DIR}"
sudo tar -xzf "${TARBALL}" -C "${APP_DIR}" --strip-components=1

echo "Installing production dependencies..."
sudo npm install --omit=dev --prefix "${APP_DIR}"

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "Creating env file template at ${ENV_FILE}"
  sudo cp "${APP_DIR}/deploy/env.example" "${ENV_FILE}"
  echo "Please edit ${ENV_FILE} and set SESSION_SECRET / ADMIN_EMAIL."
fi

echo "Installing systemd service..."
sudo cp "${APP_DIR}/deploy/internal-tls-portal.service" "/etc/systemd/system/${APP_NAME}.service"
sudo systemctl daemon-reload
sudo systemctl enable "${APP_NAME}"

echo "Nginx config is prepared but not enabled automatically."
echo "See deploy/INSTALL.md for enabling steps."

echo "Done."
