## 服务器部署指南（建议 Ubuntu 22.04 + systemd + Nginx）

以下步骤假设你有 root/sudo 权限，并且服务器可访问互联网以安装 Node.js。

### 1) 准备环境
你可以使用自动安装脚本（会在缺失时安装 Node.js 与 Nginx）：

```
./deploy/install.sh /path/to/internal-tls-portal.tar.gz
```

或手动安装（建议 Node.js 18+）：

```
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs nginx
```

### 2) 上传项目包
在本地打包：

```
./deploy/package.sh
```

将生成的 `internal-tls-portal.tar.gz` 上传到服务器，例如 `/tmp/`。

### 3) 安装应用
在服务器上执行：

```
sudo mkdir -p /opt/internal-tls-portal
sudo tar -xzf /tmp/internal-tls-portal.tar.gz -C /opt/internal-tls-portal --strip-components=1
sudo npm install --omit=dev --prefix /opt/internal-tls-portal
```

### 4) 配置环境变量
创建环境文件：

```
sudo cp /opt/internal-tls-portal/deploy/env.example /etc/internal-tls-portal.env
sudo nano /etc/internal-tls-portal.env
```

至少设置：
- `SESSION_SECRET`
- `ADMIN_EMAIL`（推荐明确指定）

### 5) 配置 systemd 服务

```
sudo cp /opt/internal-tls-portal/deploy/internal-tls-portal.service /etc/systemd/system/internal-tls-portal.service
sudo systemctl daemon-reload
sudo systemctl enable internal-tls-portal
sudo systemctl start internal-tls-portal
sudo systemctl status internal-tls-portal
```

### 6) 配置 Nginx 反向代理（可选但推荐）

```
sudo cp /opt/internal-tls-portal/deploy/nginx.conf /etc/nginx/sites-available/internal-tls-portal
sudo ln -s /etc/nginx/sites-available/internal-tls-portal /etc/nginx/sites-enabled/internal-tls-portal
sudo nginx -t
sudo systemctl reload nginx
```

### 7) HTTPS 与域名
- **是否需要域名？** 只有在你希望公网访问、使用 HTTPS 或 Let’s Encrypt 时才需要域名。
- 若仅内网访问，可使用 IP 或内部 DNS。
- 使用 Let’s Encrypt 需要域名解析到服务器并开放 80/443 端口。

### 8) 数据持久化
应用会在 `/opt/internal-tls-portal/data` 和 `/opt/internal-tls-portal/uploads` 中保存数据。
升级时请保留这两个目录。

### 9) 版本冲突说明
- 脚本只在 **未安装** Node.js 或 Nginx 时进行安装，不会覆盖已有版本。
- 如果服务器已安装 Nginx，会保留现有配置，不会自动启用新的站点配置。
