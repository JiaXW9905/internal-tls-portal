#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_FILE="${ROOT_DIR}/internal-tls-portal.tar.gz"

tar \
  --exclude="internal-tls-portal.tar.gz" \
  --exclude="node_modules" \
  --exclude="data" \
  --exclude="uploads" \
  --exclude=".DS_Store" \
  -czf "${OUT_FILE}" \
  -C "${ROOT_DIR}" .

echo "Package created: ${OUT_FILE}"
