const requestForm = document.getElementById("request-form");
const requestMessage = document.getElementById("request-message");
const lookupMessage = document.getElementById("lookup-message");
const requestsList = document.getElementById("requests-list");
const loadRequestsBtn = document.getElementById("load-requests");
const logoutBtn = document.getElementById("logout-btn");
const userBar = document.getElementById("user-bar");
const requesterNameInput = document.getElementById("requesterName");
const requestsLink = document.getElementById("nav-requests");
const adminLink = document.getElementById("nav-admin");
const overviewLink = document.getElementById("nav-overview");
const usersLink = document.getElementById("nav-users");

async function fetchJson(url, options = {}) {
  const res = await fetch(url, options);
  if (res.status === 401) {
    window.location.href = "/login";
    return null;
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || "请求失败");
  }
  return res.json();
}

function renderRequests(items) {
  requestsList.innerHTML = "";
  if (!items.length) {
    requestsList.innerHTML = "<p class=\"muted\">未找到申请记录。</p>";
    return;
  }

  items.forEach((item) => {
    const card = document.createElement("div");
    card.className = "request-card";
    card.innerHTML = `
      <h3>${item.customer_name}</h3>
      <div class="muted">SKU：${item.product_sku}</div>
      <div class="muted">VID：${item.vid}</div>
      <div class="muted">创建时间：${new Date(item.created_at).toLocaleString()}</div>
      <div class="status ${item.status}">${item.status}</div>
      <div class="actions"></div>
    `;

    const actions = card.querySelector(".actions");
    if (item.status === "issued") {
      const link = document.createElement("a");
      link.href = `/api/requests/${item.id}/download`;
      link.textContent = "下载 ZIP";
      link.className = "button";

      const pwd = document.createElement("div");
      pwd.className = "muted";
      pwd.textContent = `解压密码：${item.zip_password || "-"}`;

      actions.appendChild(link);
      card.appendChild(pwd);
    } else {
      actions.innerHTML = "<span class=\"muted\">等待签发</span>";
    }

    requestsList.appendChild(card);
  });
}

async function loadRequests() {
  lookupMessage.textContent = "加载中...";
  requestsList.innerHTML = "";
  try {
    const data = await fetchJson("/api/requests");
    if (!data) return;
    renderRequests(data);
    lookupMessage.textContent = "";
  } catch (err) {
    lookupMessage.textContent = err.message;
    lookupMessage.className = "error";
  }
}

requestForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  requestMessage.textContent = "提交中...";
  const formData = new FormData(requestForm);
  const payload = Object.fromEntries(formData.entries());

  try {
    const result = await fetchJson("/api/requests", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    if (!result) return;
    requestMessage.textContent = `申请已提交。编号：${result.id}`;
    requestMessage.className = "success";
    requestForm.reset();
  } catch (err) {
    requestMessage.textContent = err.message;
    requestMessage.className = "error";
  }
});

loadRequestsBtn.addEventListener("click", () => {
  loadRequests();
});

logoutBtn.addEventListener("click", async () => {
  try {
    await fetchJson("/api/auth/logout", { method: "POST" });
  } catch (err) {
    // ignore
  } finally {
    window.location.href = "/login";
  }
});

async function init() {
  try {
    const me = await fetchJson("/api/me");
    if (!me) return;
    userBar.textContent = `已登录：${me.name}（${me.email}）`;
    requesterNameInput.value = me.name;
    const role = me.role || (me.isAdmin ? "admin" : "service");
    if (requestsLink) {
      requestsLink.style.display = "inline-block";
    }
    if ((role === "admin" || role === "dev" || role === "product") && adminLink) {
      adminLink.style.display = "inline-block";
    }
    if ((role === "admin" || role === "dev" || role === "product") && overviewLink) {
      overviewLink.style.display = "inline-block";
    }
    if (role === "admin" && usersLink) {
      usersLink.style.display = "inline-block";
    }
    if (role === "dev" || role === "product") {
      if (requestsLink) {
        requestsLink.style.display = "none";
      }
      if (usersLink) {
        usersLink.style.display = "none";
      }
    }
    if (role === "dev" || role === "product") {
      window.location.href = "/admin";
      return;
    }
    loadRequests();
  } catch (err) {
    lookupMessage.textContent = err.message;
    lookupMessage.className = "error";
  }
}

init();
