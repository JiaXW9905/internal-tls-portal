const usersList = document.getElementById("users-list");
const usersMessage = document.getElementById("users-message");
const logoutBtn = document.getElementById("logout-btn");
const userBar = document.getElementById("user-bar");
const navRequests = document.getElementById("nav-requests");
const navAdmin = document.getElementById("nav-admin");
const navOverview = document.getElementById("nav-overview");
const navUsers = document.getElementById("nav-users");

const ROLE_LABELS = {
  admin: "管理员",
  service: "服务",
  dev: "研发",
  product: "产品"
};

async function fetchJson(url, options = {}) {
  const res = await fetch(url, options);
  if (res.status === 401) {
    window.location.href = "/login";
    return null;
  }
  if (res.status === 403) {
    usersMessage.textContent = "需要管理员权限。";
    usersMessage.className = "error";
    return null;
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || "请求失败");
  }
  return res.json();
}

function buildRoleSelect(currentRole) {
  const select = document.createElement("select");
  ["admin", "service", "dev", "product"].forEach((role) => {
    const option = document.createElement("option");
    option.value = role;
    option.textContent = ROLE_LABELS[role] || role;
    if (role === currentRole) {
      option.selected = true;
    }
    select.appendChild(option);
  });
  return select;
}

function renderUsers(users) {
  usersList.innerHTML = "";
  if (!users.length) {
    usersList.innerHTML = "<p class=\"muted\">暂无用户。</p>";
    return;
  }
  users.forEach((user) => {
    const card = document.createElement("div");
    card.className = "request-card";
    const verifiedLabel = user.email_verified ? "已验证" : "未验证";
    const currentRole = user.role || (user.is_admin ? "admin" : "service");
    card.innerHTML = `
      <h3>${user.name}</h3>
      <div class="muted">${user.email}</div>
      <div class="muted">邮箱：${verifiedLabel}</div>
      <div class="actions"></div>
    `;
    const actions = card.querySelector(".actions");
    const roleSelect = buildRoleSelect(currentRole);
    actions.appendChild(roleSelect);

    const saveBtn = document.createElement("button");
    saveBtn.type = "button";
    saveBtn.textContent = "保存角色";
    saveBtn.addEventListener("click", async () => {
      const nextRole = roleSelect.value;
      usersMessage.textContent = "正在更新角色...";
      usersMessage.className = "muted";
      try {
        await fetchJson(`/api/admin/users/${user.id}/role`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ role: nextRole })
        });
        usersMessage.textContent = "角色已更新。";
        usersMessage.className = "success";
        await loadUsers();
      } catch (err) {
        usersMessage.textContent = err.message;
        usersMessage.className = "error";
      }
    });
    actions.appendChild(saveBtn);

    if (!user.email_verified) {
      const verifyBtn = document.createElement("button");
      verifyBtn.type = "button";
      verifyBtn.textContent = "标记为已验证";
      verifyBtn.addEventListener("click", async () => {
        usersMessage.textContent = "正在更新验证状态...";
        usersMessage.className = "muted";
        try {
          await fetchJson(`/api/admin/users/${user.id}/verify`, {
            method: "POST"
          });
          usersMessage.textContent = "用户已验证。";
          usersMessage.className = "success";
          await loadUsers();
        } catch (err) {
          usersMessage.textContent = err.message;
          usersMessage.className = "error";
        }
      });
      actions.appendChild(verifyBtn);
    }

    usersList.appendChild(card);
  });
}

async function loadUsers() {
  usersMessage.textContent = "加载用户中...";
  usersMessage.className = "muted";
  try {
    const users = await fetchJson("/api/admin/users");
    if (!users) return;
    renderUsers(users);
    usersMessage.textContent = "";
  } catch (err) {
    usersMessage.textContent = err.message;
    usersMessage.className = "error";
  }
}

logoutBtn.addEventListener("click", async () => {
  try {
    await fetchJson("/api/auth/logout", { method: "POST" });
  } catch (err) {
    // ignore
  } finally {
    window.location.href = "/login";
  }
});

async function init() {
  try {
    const me = await fetchJson("/api/me");
    if (!me) return;
    userBar.textContent = `已登录：${me.name}（${me.email}）`;
    if (navRequests) navRequests.style.display = "inline-block";
    if (navAdmin) navAdmin.style.display = "inline-block";
    if (navOverview) navOverview.style.display = "inline-block";
    if (navUsers) navUsers.style.display = "inline-block";
    loadUsers();
  } catch (err) {
    usersMessage.textContent = err.message;
    usersMessage.className = "error";
  }
}

init();
