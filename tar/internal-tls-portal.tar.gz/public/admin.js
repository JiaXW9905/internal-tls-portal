const pendingList = document.getElementById("pending-list");
const issuedList = document.getElementById("issued-list");
const pendingMessage = document.getElementById("pending-message");
const logoutBtn = document.getElementById("logout-btn");
const userBar = document.getElementById("user-bar");
const requestsLink = document.getElementById("nav-requests");
const adminLink = document.getElementById("nav-admin");
const overviewLink = document.getElementById("nav-overview");
const usersLink = document.getElementById("nav-users");

async function fetchJson(url, options = {}) {
  const res = await fetch(url, options);
  if (res.status === 401) {
    window.location.href = "/login";
    return null;
  }
  if (res.status === 403) {
    pendingMessage.textContent = "需要管理员、研发或产品权限。";
    pendingMessage.className = "error";
    return null;
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || "请求失败");
  }
  return res.json();
}

function requestCard(item, isPending) {
  const card = document.createElement("div");
  card.className = "request-card";
  card.innerHTML = `
    <h3>${item.customer_name}</h3>
    <div class="muted">SKU：${item.product_sku}</div>
    <div class="muted">VID：${item.vid}</div>
    <div class="muted">申请人：${item.requester_name}（${item.requester_email}）</div>
    <div class="muted">创建时间：${new Date(item.created_at).toLocaleString()}</div>
    <div class="status ${item.status}">${item.status}</div>
  `;

  if (isPending) {
    const form = document.createElement("form");
    form.innerHTML = `
      <label>证书 ZIP 文件</label>
      <input type="file" name="zipFile" accept=".zip" required />
      <label>ZIP 密码</label>
      <input type="text" name="zipPassword" required />
      <button type="submit">上传并签发</button>
      <div class="muted"></div>
    `;
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const statusEl = form.querySelector(".muted");
      statusEl.textContent = "上传中...";

      const formData = new FormData(form);
      try {
        const res = await fetch(`/api/requests/${item.id}/issue`, {
          method: "POST",
          body: formData
        });

        if (!res.ok) {
          const error = await res.json();
          throw new Error(error.error || "签发失败");
        }

        statusEl.textContent = "已签发。";
        await loadAll();
      } catch (err) {
        statusEl.textContent = err.message;
        statusEl.className = "error";
      }
    });
    card.appendChild(form);
  } else {
    const pwd = document.createElement("div");
    pwd.className = "muted";
    pwd.textContent = `解压密码：${item.zip_password || "-"}`;
    card.appendChild(pwd);
  }

  return card;
}

function renderList(container, items, isPending) {
  container.innerHTML = "";
  if (!items.length) {
    container.innerHTML = "<p class=\"muted\">暂无数据。</p>";
    return;
  }
  items.forEach((item) => {
    container.appendChild(requestCard(item, isPending));
  });
}

async function loadAll() {
  pendingMessage.textContent = "加载中...";
  try {
    const [pending, issued] = await Promise.all([
      fetchJson("/api/requests?status=pending"),
      fetchJson("/api/requests?status=issued")
    ]);
    if (!pending || !issued) return;
    renderList(pendingList, pending, true);
    renderList(issuedList, issued, false);
    pendingMessage.textContent = "";
  } catch (err) {
    pendingMessage.textContent = err.message;
    pendingMessage.className = "error";
  }
}

logoutBtn.addEventListener("click", async () => {
  try {
    await fetchJson("/api/auth/logout", { method: "POST" });
  } catch (err) {
    // ignore
  } finally {
    window.location.href = "/login";
  }
});

async function init() {
  try {
    const me = await fetchJson("/api/me");
    if (!me) return;
    userBar.textContent = `已登录：${me.name}（${me.email}）`;
    const role = me.role || (me.isAdmin ? "admin" : "service");
    if (role === "service") {
      window.location.href = "/";
      return;
    }
    if (requestsLink) requestsLink.style.display = "inline-block";
    if (adminLink) adminLink.style.display = "inline-block";
    if (overviewLink) overviewLink.style.display = "inline-block";
    if (role === "admin" && usersLink) {
      usersLink.style.display = "inline-block";
    }
    if (role === "dev" || role === "product") {
      if (requestsLink) requestsLink.style.display = "none";
      if (usersLink) usersLink.style.display = "none";
    }
    loadAll();
  } catch (err) {
    pendingMessage.textContent = err.message;
    pendingMessage.className = "error";
  }
}

init();
