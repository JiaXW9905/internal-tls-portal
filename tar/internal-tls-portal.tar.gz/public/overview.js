const pendingList = document.getElementById("pending-list");
const issuedList = document.getElementById("issued-list");
const pendingMessage = document.getElementById("pending-message");
const issuedMessage = document.getElementById("issued-message");
const logoutBtn = document.getElementById("logout-btn");
const userBar = document.getElementById("user-bar");
const requestsLink = document.getElementById("nav-requests");
const adminLink = document.getElementById("nav-admin");
const overviewLink = document.getElementById("nav-overview");
const usersLink = document.getElementById("nav-users");

const STATUS_LABELS = {
  pending: "待处理",
  issued: "已签发"
};

const ONE_DAY_MS = 24 * 60 * 60 * 1000;
const CERT_VALIDITY_DAYS = 365 * 2;

async function fetchJson(url, options = {}) {
  const res = await fetch(url, options);
  if (res.status === 401) {
    window.location.href = "/login";
    return null;
  }
  if (res.status === 403) {
    pendingMessage.textContent = "需要管理员、研发或产品权限。";
    pendingMessage.className = "error";
    return null;
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || "请求失败");
  }
  return res.json();
}

function formatExpiry(issuedAt) {
  if (!issuedAt) return "未签发";
  const issuedDate = new Date(issuedAt);
  const expiry = new Date(issuedDate.getTime() + CERT_VALIDITY_DAYS * ONE_DAY_MS);
  return expiry.toLocaleDateString();
}

function formatIssuedAt(issuedAt) {
  if (!issuedAt) return "未签发";
  return new Date(issuedAt).toLocaleString();
}

function renderCards(container, items, showExpiry) {
  container.innerHTML = "";
  if (!items.length) {
    container.innerHTML = "<p class=\"muted\">暂无数据。</p>";
    return;
  }
  items.forEach((item) => {
    const card = document.createElement("div");
    card.className = "request-card";
    const statusLabel = STATUS_LABELS[item.status] || item.status;
    card.innerHTML = `
      <h3>${item.customer_name}</h3>
      <div class="muted">SKU：${item.product_sku}</div>
      <div class="muted">VID：${item.vid}</div>
      <div class="muted">申请人：${item.requester_name}（${item.requester_email}）</div>
      <div class="muted">创建时间：${new Date(item.created_at).toLocaleString()}</div>
      <div class="status ${item.status}">${statusLabel}</div>
      <div class="actions"></div>
    `;
    const actions = card.querySelector(".actions");
    if (showExpiry) {
      const issuedInfo = document.createElement("div");
      issuedInfo.className = "muted";
      issuedInfo.textContent = `签发时间：${formatIssuedAt(item.issued_at)}`;
      const expiryInfo = document.createElement("div");
      expiryInfo.className = "muted";
      expiryInfo.textContent = `有效期至：${formatExpiry(item.issued_at)}`;
      card.appendChild(issuedInfo);
      card.appendChild(expiryInfo);
    } else {
      actions.innerHTML = "<span class=\"muted\">等待签发</span>";
    }
    container.appendChild(card);
  });
}

async function loadOverview() {
  pendingMessage.textContent = "加载中...";
  issuedMessage.textContent = "加载中...";
  try {
    const [pending, issued] = await Promise.all([
      fetchJson("/api/requests?status=pending"),
      fetchJson("/api/requests?status=issued")
    ]);
    if (!pending || !issued) return;
    renderCards(pendingList, pending, false);
    renderCards(issuedList, issued, true);
    pendingMessage.textContent = "";
    issuedMessage.textContent = "";
  } catch (err) {
    pendingMessage.textContent = err.message;
    pendingMessage.className = "error";
    issuedMessage.textContent = err.message;
    issuedMessage.className = "error";
  }
}

logoutBtn.addEventListener("click", async () => {
  try {
    await fetchJson("/api/auth/logout", { method: "POST" });
  } catch (err) {
    // ignore
  } finally {
    window.location.href = "/login";
  }
});

async function init() {
  try {
    const me = await fetchJson("/api/me");
    if (!me) return;
    userBar.textContent = `已登录：${me.name}（${me.email}）`;
    const role = me.role || (me.isAdmin ? "admin" : "service");
    if (role === "service") {
      window.location.href = "/";
      return;
    }
    if (requestsLink) requestsLink.style.display = "inline-block";
    if (adminLink) adminLink.style.display = "inline-block";
    if (overviewLink) overviewLink.style.display = "inline-block";
    if (role === "admin" && usersLink) {
      usersLink.style.display = "inline-block";
    }
    if (role === "dev" || role === "product") {
      if (requestsLink) requestsLink.style.display = "none";
      if (usersLink) usersLink.style.display = "none";
    }
    loadOverview();
  } catch (err) {
    pendingMessage.textContent = err.message;
    pendingMessage.className = "error";
  }
}

init();
