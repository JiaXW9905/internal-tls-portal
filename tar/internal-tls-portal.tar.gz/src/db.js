const path = require("path");
const fs = require("fs");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");

const dataDir = path.join(__dirname, "..", "data");
const dbPath = path.join(dataDir, "app.db");

function ensureDataDir() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
}

async function initDb() {
  ensureDataDir();
  const db = await open({
    filename: dbPath,
    driver: sqlite3.Database
  });

  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      is_admin INTEGER NOT NULL DEFAULT 0,
      role TEXT NOT NULL DEFAULT 'service',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS email_verifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      code TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT NOT NULL,
      product_sku TEXT NOT NULL,
      vid TEXT NOT NULL,
      requester_name TEXT NOT NULL,
      requester_email TEXT NOT NULL,
      status TEXT NOT NULL,
      zip_path TEXT,
      zip_password TEXT,
      created_at TEXT NOT NULL,
      issued_at TEXT
    );
  `);

  const userColumns = await db.all("PRAGMA table_info(users)");
  const hasEmailVerified = userColumns.some((col) => col.name === "email_verified");
  if (!hasEmailVerified) {
    await db.exec(
      "ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0"
    );
    await db.run("UPDATE users SET email_verified = 1 WHERE email_verified IS NULL");
  }

  const hasRole = userColumns.some((col) => col.name === "role");
  if (!hasRole) {
    await db.exec(
      "ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'service'"
    );
    await db.run("UPDATE users SET role = 'admin' WHERE is_admin = 1");
  }

  return db;
}

module.exports = {
  initDb
};
