const path = require("path");
const fs = require("fs");
const express = require("express");
const multer = require("multer");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const { initDb } = require("./db");

const app = express();
const port = process.env.PORT || 3000;
const uploadsDir = path.join(__dirname, "..", "uploads");

function ensureUploadsDir() {
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
}

ensureUploadsDir();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const safeExt = path.extname(file.originalname).toLowerCase() || ".zip";
    const name = `${req.params.id}-${Date.now()}${safeExt}`;
    cb(null, name);
  }
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== ".zip") {
      return cb(new Error("Only .zip files are allowed"));
    }
    return cb(null, true);
  },
  limits: {
    fileSize: 50 * 1024 * 1024
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "..", "public")));
app.use(
  session({
    secret: process.env.SESSION_SECRET || "dev-secret-change-me",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax"
    }
  })
);

app.get("/api/health", (req, res) => {
  res.json({ ok: true });
});

initDb()
  .then((db) => {
    const adminEmail =
      (process.env.ADMIN_EMAIL || "").trim().toLowerCase() || null;
    const defaultAdminEmail = "wangjiaxin@shengwang.cn";
    const verificationMinutes = Number(process.env.VERIFICATION_TTL_MINUTES) || 10;
    const ROLE_ADMIN = "admin";
    const ROLE_DEV = "dev";
    const ROLE_SERVICE = "service";
    const ROLE_PRODUCT = "product";

    function requireAuth(req, res, next) {
      if (!req.session.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      return next();
    }

    function getRole(user) {
      if (!user) return null;
      if (user.role) return user.role;
      return user.isAdmin ? ROLE_ADMIN : ROLE_SERVICE;
    }

    function requireAdmin(req, res, next) {
      if (!req.session.user || getRole(req.session.user) !== ROLE_ADMIN) {
        return res.status(403).json({ error: "Admin only" });
      }
      return next();
    }

    function requireRole(roles) {
      return (req, res, next) => {
        if (!req.session.user) {
          return res.status(401).json({ error: "Unauthorized" });
        }
        const role = getRole(req.session.user);
        if (!roles.includes(role)) {
          return res.status(403).json({ error: "Forbidden" });
        }
        return next();
      };
    }

    function isAllowedEmail(email) {
      return email.toLowerCase().endsWith("@shengwang.cn");
    }

    function generateVerificationCode() {
      return Math.floor(100000 + Math.random() * 900000).toString();
    }

    function nowIso() {
      return new Date().toISOString();
    }

    function expiresAt(minutes) {
      return new Date(Date.now() + minutes * 60 * 1000).toISOString();
    }

    app.post("/api/auth/send-code", async (req, res) => {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Missing email" });
      }
      if (!isAllowedEmail(email)) {
        return res
          .status(400)
          .json({ error: "Email must be @shengwang.cn" });
      }

      const normalizedEmail = email.toLowerCase();
      const code = generateVerificationCode();
      const now = nowIso();
      const exp = expiresAt(verificationMinutes);

      await db.run("DELETE FROM email_verifications WHERE email = ?", [
        normalizedEmail
      ]);
      await db.run(
        `
          INSERT INTO email_verifications (email, code, expires_at, created_at)
          VALUES (?, ?, ?, ?)
        `,
        normalizedEmail,
        code,
        exp,
        now
      );

      const payload = { ok: true, expiresInMinutes: verificationMinutes };
      if (process.env.NODE_ENV !== "production") {
        payload.devCode = code;
      }

      console.log(`[verify] ${normalizedEmail} code: ${code} (exp: ${exp})`);
      return res.json(payload);
    });

    app.post("/api/auth/register", async (req, res) => {
      const { name, email, password, code } = req.body;
      if (!name || !email || !password || !code) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      if (!isAllowedEmail(email)) {
        return res
          .status(400)
          .json({ error: "Email must be @shengwang.cn" });
      }

      const existing = await db.get("SELECT id FROM users WHERE email = ?", [
        email.toLowerCase()
      ]);
      if (existing) {
        return res.status(400).json({ error: "Email already registered" });
      }

      const verification = await db.get(
        "SELECT * FROM email_verifications WHERE email = ?",
        [email.toLowerCase()]
      );
      if (!verification || verification.code !== code) {
        return res.status(400).json({ error: "Invalid verification code" });
      }
      if (new Date(verification.expires_at).getTime() < Date.now()) {
        return res.status(400).json({ error: "Verification code expired" });
      }

      const hash = await bcrypt.hash(password, 10);
      const now = nowIso();
      const normalizedEmail = email.toLowerCase();
      const isAdmin =
        normalizedEmail === (adminEmail || defaultAdminEmail) ||
        normalizedEmail === defaultAdminEmail
          ? 1
          : 0;
      const role = isAdmin ? ROLE_ADMIN : ROLE_SERVICE;

      const result = await db.run(
        `
          INSERT INTO users (email, name, password_hash, is_admin, role, email_verified, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
        normalizedEmail,
        name,
        hash,
        isAdmin,
        role,
        1,
        now
      );

      await db.run("DELETE FROM email_verifications WHERE email = ?", [
        email.toLowerCase()
      ]);

      req.session.user = {
        id: result.lastID,
        email: normalizedEmail,
        name,
        role,
        isAdmin: !!isAdmin,
        emailVerified: true
      };

      return res.json({ ok: true });
    });

    app.post("/api/auth/login", async (req, res) => {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      const user = await db.get("SELECT * FROM users WHERE email = ?", [
        email.toLowerCase()
      ]);
      if (!user) {
        return res.status(400).json({ error: "Invalid credentials" });
      }
      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        return res.status(400).json({ error: "Invalid credentials" });
      }
      if (!user.email_verified) {
        return res.status(400).json({ error: "Email not verified" });
      }
      const role = user.role || (user.is_admin ? ROLE_ADMIN : ROLE_SERVICE);
      req.session.user = {
        id: user.id,
        email: user.email,
        name: user.name,
        role,
        isAdmin: role === ROLE_ADMIN,
        emailVerified: !!user.email_verified
      };
      return res.json({ ok: true });
    });

    app.post("/api/auth/logout", (req, res) => {
      req.session.destroy(() => {
        res.json({ ok: true });
      });
    });

    app.get("/api/me", requireAuth, (req, res) => {
      const role = getRole(req.session.user);
      return res.json({ ...req.session.user, role, isAdmin: role === ROLE_ADMIN });
    });

    app.get("/api/admin/users", requireAdmin, async (req, res) => {
      const rows = await db.all(
        `
          SELECT id, email, name, is_admin, role, email_verified, created_at
          FROM users
          ORDER BY created_at DESC
        `
      );
      return res.json(rows);
    });

    app.post("/api/admin/users/:id/role", requireAdmin, async (req, res) => {
      const { role } = req.body;
      if (![ROLE_ADMIN, ROLE_DEV, ROLE_SERVICE, ROLE_PRODUCT].includes(role)) {
        return res.status(400).json({ error: "Invalid role" });
      }
      const target = await db.get(
        "SELECT id, role, is_admin FROM users WHERE id = ?",
        [req.params.id]
      );
      if (!target) {
        return res.status(404).json({ error: "User not found" });
      }
      if (target.role === ROLE_ADMIN && role !== ROLE_ADMIN) {
        const adminCountRow = await db.get(
          "SELECT COUNT(*) as count FROM users WHERE role = 'admin' OR is_admin = 1"
        );
        const adminCount = adminCountRow ? adminCountRow.count : 0;
        if (adminCount <= 1) {
          return res.status(400).json({ error: "At least one admin required" });
        }
      }
      const isAdmin = role === ROLE_ADMIN ? 1 : 0;
      await db.run("UPDATE users SET role = ?, is_admin = ? WHERE id = ?", [
        role,
        isAdmin,
        target.id
      ]);
      return res.json({ ok: true, role });
    });

    app.post("/api/admin/users/:id/toggle-admin", requireAdmin, async (req, res) => {
      const target = await db.get(
        "SELECT id, role, is_admin FROM users WHERE id = ?",
        [req.params.id]
      );
      if (!target) {
        return res.status(404).json({ error: "User not found" });
      }
      const adminCountRow = await db.get(
        "SELECT COUNT(*) as count FROM users WHERE role = 'admin' OR is_admin = 1"
      );
      const adminCount = adminCountRow ? adminCountRow.count : 0;
      const isCurrentlyAdmin =
        target.role === ROLE_ADMIN || target.is_admin === 1;
      if (isCurrentlyAdmin && adminCount <= 1) {
        return res.status(400).json({ error: "At least one admin required" });
      }
      const nextRole = isCurrentlyAdmin ? ROLE_SERVICE : ROLE_ADMIN;
      const nextValue = isCurrentlyAdmin ? 0 : 1;
      await db.run("UPDATE users SET role = ?, is_admin = ? WHERE id = ?", [
        nextRole,
        nextValue,
        target.id
      ]);
      return res.json({ ok: true, isAdmin: !isCurrentlyAdmin });
    });

    app.post("/api/admin/users/:id/verify", requireAdmin, async (req, res) => {
      const target = await db.get("SELECT id FROM users WHERE id = ?", [
        req.params.id
      ]);
      if (!target) {
        return res.status(404).json({ error: "User not found" });
      }
      await db.run("UPDATE users SET email_verified = 1 WHERE id = ?", [
        target.id
      ]);
      return res.json({ ok: true });
    });

    app.post(
      "/api/requests",
      requireRole([ROLE_ADMIN, ROLE_SERVICE]),
      async (req, res) => {
      const {
        customerName,
        productSku,
        vid,
        requesterName
      } = req.body;

      if (
        !customerName ||
        !productSku ||
        !vid
      ) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const finalRequesterName = requesterName || req.session.user.name;
      if (!finalRequesterName) {
        return res.status(400).json({ error: "Missing requester name" });
      }

      const now = new Date().toISOString();
      const result = await db.run(
        `
          INSERT INTO requests
            (customer_name, product_sku, vid, requester_name, requester_email, status, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
        customerName,
        productSku,
        vid,
        finalRequesterName,
        req.session.user.email,
        "pending",
        now
      );

        return res.json({ id: result.lastID });
      }
    );

    app.get("/api/requests", requireAuth, async (req, res) => {
      const { email, status } = req.query;
      const clauses = [];
      const params = [];

      const role = getRole(req.session.user);
      if (role === ROLE_ADMIN || role === ROLE_DEV || role === ROLE_PRODUCT) {
        if (email) {
          clauses.push("requester_email = ?");
          params.push(email);
        }
        if (status) {
          clauses.push("status = ?");
          params.push(status);
        }
      } else {
        clauses.push("requester_email = ?");
        params.push(req.session.user.email);
      }

      const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
      const rows = await db.all(
        `
          SELECT *
          FROM requests
          ${where}
          ORDER BY created_at DESC
        `,
        params
      );

      return res.json(rows);
    });

    app.get("/api/requests/:id", requireAuth, async (req, res) => {
      const row = await db.get("SELECT * FROM requests WHERE id = ?", [
        req.params.id
      ]);
      if (!row) {
        return res.status(404).json({ error: "Request not found" });
      }
      const role = getRole(req.session.user);
      if (
        role !== ROLE_ADMIN &&
        role !== ROLE_DEV &&
        role !== ROLE_PRODUCT &&
        row.requester_email !== req.session.user.email
      ) {
        return res.status(403).json({ error: "Forbidden" });
      }
      return res.json(row);
    });

    app.post(
      "/api/requests/:id/issue",
      requireRole([ROLE_ADMIN, ROLE_DEV, ROLE_PRODUCT]),
      upload.single("zipFile"),
      async (req, res) => {
        const { zipPassword } = req.body;
        if (!req.file || !zipPassword) {
          return res.status(400).json({ error: "Missing file or password" });
        }

        const row = await db.get("SELECT * FROM requests WHERE id = ?", [
          req.params.id
        ]);
        if (!row) {
          return res.status(404).json({ error: "Request not found" });
        }

        const now = new Date().toISOString();
        await db.run(
          `
            UPDATE requests
            SET status = ?, zip_path = ?, zip_password = ?, issued_at = ?
            WHERE id = ?
          `,
          "issued",
          req.file.filename,
          zipPassword,
          now,
          req.params.id
        );

        return res.json({ ok: true });
      }
    );

    app.get("/api/requests/:id/download", async (req, res) => {
      if (!req.session.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      const row = await db.get("SELECT * FROM requests WHERE id = ?", [
        req.params.id
      ]);
      if (!row) {
        return res.status(404).json({ error: "Request not found" });
      }
      const role = getRole(req.session.user);
      if (
        role !== ROLE_ADMIN &&
        role !== ROLE_DEV &&
        role !== ROLE_PRODUCT &&
        row.requester_email !== req.session.user.email
      ) {
        return res.status(403).json({ error: "Forbidden" });
      }
      if (row.status !== "issued" || !row.zip_path) {
        return res.status(400).json({ error: "Certificate not issued" });
      }

      const fullPath = path.join(uploadsDir, row.zip_path);
      if (!fs.existsSync(fullPath)) {
        return res.status(404).json({ error: "File missing on server" });
      }

      return res.download(fullPath, `certificate-${row.id}.zip`);
    });

    app.get("/login", (req, res) => {
      res.sendFile(path.join(__dirname, "..", "public", "login.html"));
    });

    app.get("/register", (req, res) => {
      res.sendFile(path.join(__dirname, "..", "public", "register.html"));
    });

    app.get("/admin", (req, res) => {
      if (!req.session.user) {
        return res.redirect("/login");
      }
      const role = getRole(req.session.user);
      if (role === ROLE_SERVICE) {
        return res.redirect("/");
      }
      if (role !== ROLE_ADMIN && role !== ROLE_DEV && role !== ROLE_PRODUCT) {
        return res.status(403).send("Admin or developer only");
      }
      return res.sendFile(path.join(__dirname, "..", "public", "admin.html"));
    });

    app.get("/users", (req, res) => {
      if (!req.session.user) {
        return res.redirect("/login");
      }
      const role = getRole(req.session.user);
      if (role !== ROLE_ADMIN) {
        return res.status(403).send("Admin only");
      }
      return res.sendFile(path.join(__dirname, "..", "public", "users.html"));
    });

    app.get("/overview", (req, res) => {
      if (!req.session.user) {
        return res.redirect("/login");
      }
      const role = getRole(req.session.user);
      if (role === ROLE_SERVICE) {
        return res.redirect("/");
      }
      if (role !== ROLE_ADMIN && role !== ROLE_DEV && role !== ROLE_PRODUCT) {
        return res.status(403).send("Admin, developer, or product only");
      }
      return res.sendFile(path.join(__dirname, "..", "public", "overview.html"));
    });

    app.get("/", (req, res) => {
      if (!req.session.user) {
        return res.redirect("/login");
      }
      const role = getRole(req.session.user);
      if (role === ROLE_DEV || role === ROLE_PRODUCT) {
        return res.redirect("/admin");
      }
      return res.sendFile(path.join(__dirname, "..", "public", "index.html"));
    });

    app.listen(port, () => {
      console.log(`Server listening on http://localhost:${port}`);
    });
  })
  .catch((err) => {
    console.error("Failed to start server:", err);
    process.exit(1);
  });
