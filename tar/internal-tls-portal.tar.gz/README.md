# Internal TLS Certificate Portal

This project provides a simple internal portal for requesting, issuing, and
downloading TLS certificate zip packages.

## Features
- Project owner submits a request with customer name, product SKU, and VID.
- R&D issues the certificate and uploads a zip package with its password.
- Applicants can download the zip file and view the password.

## Setup
1. Install dependencies:
   - `npm install`
2. Start the server:
   - `npm start`

The server runs on `http://localhost:3000` by default.

## Pages
- Login: `http://localhost:3000/login`
- Register: `http://localhost:3000/register`
- Request portal: `http://localhost:3000/`
- Issuance portal (admin): `http://localhost:3000/admin`

## Auth
- Registration and login require an `@shengwang.cn` email.
- Admin is determined by `ADMIN_EMAIL` environment variable.
- If `ADMIN_EMAIL` is not set, the first registered user becomes admin.
- Set `SESSION_SECRET` in production.
- Email verification requires a code sent from the registration page.

## Data
The SQLite database is stored in `data/app.db`, and uploaded zips are stored in
`uploads/`.

## Deployment
See `deploy/INSTALL.md` for a ready-to-use deployment guide, systemd service,
and Nginx reverse proxy config.
